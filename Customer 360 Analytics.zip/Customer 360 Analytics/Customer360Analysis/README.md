# Customer360Analysis
The project aims to create an end to end solution with customer data, from data engineering to data analysis and data science focusing on three different domains of customer that is customer segmentation, customer churn and customer lifetime valure prediction
